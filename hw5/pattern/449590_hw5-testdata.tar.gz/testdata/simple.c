int INT;
float FLOAT;

int MAIN() {
  write(INT);
  write("\n");
  write(FLOAT);
  write("\n");

  FLOAT = 3.14159;
  write(FLOAT);
  write("\n");
  FLOAT = 0.123;
  write(FLOAT);
  write("\n");

  INT = 123213;
  write(INT);
  write("\n");
  INT = -9830483;
  write(INT);
  write("\n");
  FLOAT = 1000000000000000000.000000;
  write(FLOAT);
  write("\n");
}
