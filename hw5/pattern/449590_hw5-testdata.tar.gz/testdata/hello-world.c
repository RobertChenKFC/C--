int MAIN() {
  write("hello world!\n");
}
