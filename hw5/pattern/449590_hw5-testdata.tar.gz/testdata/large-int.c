int MAIN() {
  int x;
  x = 1000000000 + 1000000000;
  write(x);
  write("\n");
}
