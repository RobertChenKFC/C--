int a[123123];
int c;
int b[456456];
int d;
int e[789789];

void f() {
  a[123] = 321;
}

void g() {
  c = 321321;
}

void h() {
  b[456] = 654;
}

void i() {
  d = 654654;
}

void j() {
  e[789] = 987;
}

int MAIN() {
  write(a[123]);
  write("\n");
  write(c);
  write("\n");
  write(b[456]);
  write("\n");
  write(d);
  write("\n");
  write(e[789]);
  write("\n");
  f();
  write(a[123]);
  write("\n");
  write(c);
  write("\n");
  write(b[456]);
  write("\n");
  write(d);
  write("\n");
  write(e[789]);
  write("\n");
  g();
  write(a[123]);
  write("\n");
  write(c);
  write("\n");
  write(b[456]);
  write("\n");
  write(d);
  write("\n");
  write(e[789]);
  write("\n");
  h();
  write(a[123]);
  write("\n");
  write(c);
  write("\n");
  write(b[456]);
  write("\n");
  write(d);
  write("\n");
  write(e[789]);
  write("\n");
  i();
  write(a[123]);
  write("\n");
  write(c);
  write("\n");
  write(b[456]);
  write("\n");
  write(d);
  write("\n");
  write(e[789]);
  write("\n");
  j();
  write(a[123]);
  write("\n");
  write(c);
  write("\n");
  write(b[456]);
  write("\n");
  write(d);
  write("\n");
  write(e[789]);
  write("\n");
}
