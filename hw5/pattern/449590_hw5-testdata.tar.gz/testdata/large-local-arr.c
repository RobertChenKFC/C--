int MAIN() {
  int a[1000000];
  int b;
  b = 0;
  a[123] = 123;
  write(b);
  write(a[123]);
}
