int MAIN() {
  int a[1000000];
  int b;
  int c[1000000];
  b = 0;
  a[123] = 123;
  c[456] = 456;
  write(b);
  write(a[123]);
  write(c[456]);
}
