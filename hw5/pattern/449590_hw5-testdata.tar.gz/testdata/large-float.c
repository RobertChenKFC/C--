int MAIN() {
  float x;
  float y;
  x = 1000000000.000000;
  y = 0.000000001;
  write(x * y);
  write("\n");
}
