int i;
int MAIN() {
  i = 0;
  while (i < 10) {
    write(i);
    write("\n");
    i = i + 1;
  }
}
